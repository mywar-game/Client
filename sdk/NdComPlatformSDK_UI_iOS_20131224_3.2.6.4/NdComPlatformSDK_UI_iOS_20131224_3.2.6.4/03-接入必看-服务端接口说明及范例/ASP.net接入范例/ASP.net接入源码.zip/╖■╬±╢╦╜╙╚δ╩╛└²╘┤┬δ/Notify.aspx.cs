﻿using System;
using System.Collections.Generic;
using System.Web;

namespace NetDragon.MobileCenter.DemoAP
{
    public partial class Notify : System.Web.UI.Page
    {
        string appKey = "C28454605B9312157C2F76F27A9BCA2349434E546A6E9C75"; // 91通用平台分配给业务系统的AppKey
        protected void Page_Load(object sender, EventArgs e)
        {
            // 接收来自支付中心的订单结果
            int result = 0;
            string errorDesc = "未知错误";

            string act = Request["Act"];
            switch (act)
            {
                case "1":
                    result = Process_Act1(out errorDesc);
                    break;
                case "2":
                    result = Process_Act2(out errorDesc);
                    break;
                default:
                    result = 3; // Act 无效
                    break;
            }

            // 返回结果给通用平台服务器
            Response.Clear();
            Dictionary<string, string> resultDict = new Dictionary<string, string>();
            resultDict.Add("ErrorCode", result.ToString());
            resultDict.Add("ErrorDesc", errorDesc);
            Response.Write(resultDict.ToJson());
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        #region 接收通用平台的支付成功通知
        private int Process_Act1(out string errorDesc)
        {
            int result = 0;
            errorDesc = "接收失败";
            try
            {
                int productId = int.Parse(Request["AppId"]); // 应用ID
                string productName = Request["ProductName"]; // 应用名称
                string consumeStreamId = Request["ConsumeStreamId"]; // 消费流水号
                string cooOrderSerial = Request["CooOrderSerial"]; // 商户订单流水号
                long uin = long.Parse(Request["Uin"]); // 91账号ID
                string goodsID = Request["GoodsID"]; // 商品ID
                string goodsInfo = Request["GoodsInfo"]; // 商品名称
                int goodsCount = int.Parse(Request["GoodsCount"]); // 商品数量
                decimal originalMoney = decimal.Parse(Request["OriginalMoney"]); // 原价
                decimal orderMoney = decimal.Parse(Request["OrderMoney"]); // 实际价格
                string note = Request["Note"]; // 备注信息
                int payStatus = int.Parse(Request["PayStatus"]); // 支付状态：0=失败，1=成功
                string createTime = Request["CreateTime"]; // 订单流水创建时间
                string Sign = Request["Sign"];

                // 检查校验码
                string mySign = String.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}{9:0.00}{10:0.00}{11}{12}{13:yyyy-MM-dd HH:mm:ss}{14}",
                    productId, 1, productName, consumeStreamId, cooOrderSerial, uin, goodsID, goodsInfo,
                    goodsCount, originalMoney, orderMoney, note, payStatus, createTime, appKey).HashToMD5Hex();

                if (mySign == Sign)
                {
                    if (payStatus == 1) // 通用平台支付成功
                    {
                        // TODO: 支付成功，给Uin对应的用户分发所购买的物品，这步由各个开发商自行完成。
                    }
                    result = 1;
                    errorDesc = "接收成功";
                }
                else
                {
                    result = 5;
                    errorDesc = "Sign无效";
                }
            }
            catch
            {
            }
            return result;
        }
        #endregion

        #region 接收通用平台的虚拟币直充成功通知
        private int Process_Act2(out string errorDesc)
        {
            int result = 0;
            errorDesc = "接收失败";
            try
            {
                int productId = int.Parse(Request["ProductId"]); // 应用ID
                string productName = Request["ProductName"]; // 应用名称
                string creditOrderNo = Request["CreditOrderNo"]; // 充值订单流水号
                long uin = long.Parse(Request["Uin"]); // 91账号ID
                decimal creditMoney = decimal.Parse(Request["CreditMoney"]); // 充值金额
                string note = Request["Note"]; // 备注信息
                string creditTime = Request["CreditTime"]; // 充值时间
                int creditStatus = int.Parse(Request["CreditStatus"]); // 支付状态：0=失败，1=成功
                string Sign = Request["Sign"];

                // 检查校验码
                string mySign = String.Format("{0}{1}{2}{3}{4}{5:0.00}{6}{7:yyyy-MM-dd HH:mm:ss}{8}{9}",
                    productId, 2, productName, creditOrderNo, uin, creditMoney,
                    "", creditTime, creditStatus, appKey).HashToMD5Hex();

                if (mySign == Sign)
                {
                    if (creditStatus == 1) // 通用平台虚拟币直充成功
                    {
                        // TODO: 支付成功，给Uin对应的用户分发所购买的物品，这步由各个开发商自行完成。
                    }
                    result = 1;
                    errorDesc = "接收成功";
                }
                else
                {
                    result = 5;
                    errorDesc = "Sign无效";
                }
            }
            catch
            {
            }
            return result;
        }
        #endregion

    }
}